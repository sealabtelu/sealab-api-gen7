--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 14.11 (Ubuntu 14.11-0ubuntu0.22.04.1)
-- Dumped by pg_dump version 15.2

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE sealab;
--
-- Name: sealab; Type: DATABASE; Schema: -; Owner: -
--

CREATE DATABASE sealab WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'C.UTF-8';


\connect sealab

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA public;


--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON SCHEMA public IS 'standard public schema';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: __EFMigrationsHistory; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."__EFMigrationsHistory" (
    migration_id character varying(150) NOT NULL,
    product_version character varying(32) NOT NULL
);


--
-- Name: assistant; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.assistant (
    id uuid NOT NULL,
    id_user uuid NOT NULL,
    code text,
    "position" text
);


--
-- Name: g_form_survey; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.g_form_survey (
    id uuid NOT NULL,
    id_user uuid NOT NULL,
    response text
);


--
-- Name: journal_answer; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.journal_answer (
    id uuid NOT NULL,
    id_student uuid NOT NULL,
    id_module uuid NOT NULL,
    assistant_feedback text,
    session_feedback text,
    laboratory_feedback text,
    file_path text,
    submit_time timestamp without time zone NOT NULL
);


--
-- Name: module; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.module (
    id uuid NOT NULL,
    seelabs_id integer NOT NULL,
    name text,
    is_pa_open boolean NOT NULL,
    is_prt_open boolean NOT NULL,
    is_j_open boolean DEFAULT false NOT NULL
);


--
-- Name: pre_test_answer; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.pre_test_answer (
    id uuid NOT NULL,
    id_option uuid NOT NULL,
    id_student uuid NOT NULL
);


--
-- Name: pre_test_option; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.pre_test_option (
    id uuid NOT NULL,
    id_question uuid NOT NULL,
    option text,
    is_true boolean NOT NULL
);


--
-- Name: pre_test_question; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.pre_test_question (
    id uuid NOT NULL,
    id_module uuid NOT NULL,
    type text,
    question text,
    file_path text
);


--
-- Name: preliminary_assignment_answer; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.preliminary_assignment_answer (
    id uuid NOT NULL,
    id_student uuid NOT NULL,
    id_module uuid NOT NULL,
    file_path text,
    submit_time timestamp without time zone NOT NULL
);


--
-- Name: preliminary_assignment_question; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.preliminary_assignment_question (
    id uuid NOT NULL,
    id_module uuid NOT NULL,
    type text,
    question text,
    answer_key text,
    file_path text
);


--
-- Name: student; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.student (
    id uuid NOT NULL,
    id_user uuid NOT NULL,
    classroom text,
    "group" integer NOT NULL,
    day integer NOT NULL,
    shift integer NOT NULL
);


--
-- Name: user; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."user" (
    id uuid NOT NULL,
    nim text,
    email text,
    name text,
    username text,
    password text,
    role text,
    phone text,
    app_token text
);


--
-- Data for Name: __EFMigrationsHistory; Type: TABLE DATA; Schema: public; Owner: -
--

\i $$PATH$$/3402.dat

--
-- Data for Name: assistant; Type: TABLE DATA; Schema: public; Owner: -
--

\i $$PATH$$/3407.dat

--
-- Data for Name: g_form_survey; Type: TABLE DATA; Schema: public; Owner: -
--

\i $$PATH$$/3413.dat

--
-- Data for Name: journal_answer; Type: TABLE DATA; Schema: public; Owner: -
--

\i $$PATH$$/3411.dat

--
-- Data for Name: module; Type: TABLE DATA; Schema: public; Owner: -
--

\i $$PATH$$/3403.dat

--
-- Data for Name: pre_test_answer; Type: TABLE DATA; Schema: public; Owner: -
--

\i $$PATH$$/3412.dat

--
-- Data for Name: pre_test_option; Type: TABLE DATA; Schema: public; Owner: -
--

\i $$PATH$$/3409.dat

--
-- Data for Name: pre_test_question; Type: TABLE DATA; Schema: public; Owner: -
--

\i $$PATH$$/3405.dat

--
-- Data for Name: preliminary_assignment_answer; Type: TABLE DATA; Schema: public; Owner: -
--

\i $$PATH$$/3410.dat

--
-- Data for Name: preliminary_assignment_question; Type: TABLE DATA; Schema: public; Owner: -
--

\i $$PATH$$/3406.dat

--
-- Data for Name: student; Type: TABLE DATA; Schema: public; Owner: -
--

\i $$PATH$$/3408.dat

--
-- Data for Name: user; Type: TABLE DATA; Schema: public; Owner: -
--

\i $$PATH$$/3404.dat

--
-- Name: __EFMigrationsHistory pk___ef_migrations_history; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."__EFMigrationsHistory"
    ADD CONSTRAINT pk___ef_migrations_history PRIMARY KEY (migration_id);


--
-- Name: assistant pk_assistant; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.assistant
    ADD CONSTRAINT pk_assistant PRIMARY KEY (id);


--
-- Name: g_form_survey pk_g_form_survey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.g_form_survey
    ADD CONSTRAINT pk_g_form_survey PRIMARY KEY (id);


--
-- Name: journal_answer pk_journal_answer; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.journal_answer
    ADD CONSTRAINT pk_journal_answer PRIMARY KEY (id);


--
-- Name: module pk_module; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.module
    ADD CONSTRAINT pk_module PRIMARY KEY (id);


--
-- Name: pre_test_answer pk_pre_test_answer; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pre_test_answer
    ADD CONSTRAINT pk_pre_test_answer PRIMARY KEY (id);


--
-- Name: pre_test_option pk_pre_test_option; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pre_test_option
    ADD CONSTRAINT pk_pre_test_option PRIMARY KEY (id);


--
-- Name: pre_test_question pk_pre_test_question; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pre_test_question
    ADD CONSTRAINT pk_pre_test_question PRIMARY KEY (id);


--
-- Name: preliminary_assignment_answer pk_preliminary_assignment_answer; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.preliminary_assignment_answer
    ADD CONSTRAINT pk_preliminary_assignment_answer PRIMARY KEY (id);


--
-- Name: preliminary_assignment_question pk_preliminary_assignment_question; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.preliminary_assignment_question
    ADD CONSTRAINT pk_preliminary_assignment_question PRIMARY KEY (id);


--
-- Name: student pk_student; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.student
    ADD CONSTRAINT pk_student PRIMARY KEY (id);


--
-- Name: user pk_user; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."user"
    ADD CONSTRAINT pk_user PRIMARY KEY (id);


--
-- Name: ix_assistant_id_user; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_assistant_id_user ON public.assistant USING btree (id_user);


--
-- Name: ix_g_form_survey_id_user; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_g_form_survey_id_user ON public.g_form_survey USING btree (id_user);


--
-- Name: ix_journal_answer_id_module; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_journal_answer_id_module ON public.journal_answer USING btree (id_module);


--
-- Name: ix_journal_answer_id_student; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_journal_answer_id_student ON public.journal_answer USING btree (id_student);


--
-- Name: ix_pre_test_answer_id_option; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_pre_test_answer_id_option ON public.pre_test_answer USING btree (id_option);


--
-- Name: ix_pre_test_answer_id_student; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_pre_test_answer_id_student ON public.pre_test_answer USING btree (id_student);


--
-- Name: ix_pre_test_option_id_question; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_pre_test_option_id_question ON public.pre_test_option USING btree (id_question);


--
-- Name: ix_pre_test_question_id_module; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_pre_test_question_id_module ON public.pre_test_question USING btree (id_module);


--
-- Name: ix_preliminary_assignment_answer_id_module; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_preliminary_assignment_answer_id_module ON public.preliminary_assignment_answer USING btree (id_module);


--
-- Name: ix_preliminary_assignment_answer_id_student; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_preliminary_assignment_answer_id_student ON public.preliminary_assignment_answer USING btree (id_student);


--
-- Name: ix_preliminary_assignment_question_id_module; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_preliminary_assignment_question_id_module ON public.preliminary_assignment_question USING btree (id_module);


--
-- Name: ix_student_id_user; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_student_id_user ON public.student USING btree (id_user);


--
-- Name: assistant fk_assistant_user_id_user; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.assistant
    ADD CONSTRAINT fk_assistant_user_id_user FOREIGN KEY (id_user) REFERENCES public."user"(id) ON DELETE CASCADE;


--
-- Name: g_form_survey fk_g_form_survey_user_id_user; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.g_form_survey
    ADD CONSTRAINT fk_g_form_survey_user_id_user FOREIGN KEY (id_user) REFERENCES public."user"(id) ON DELETE CASCADE;


--
-- Name: journal_answer fk_journal_answer_module_id_module; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.journal_answer
    ADD CONSTRAINT fk_journal_answer_module_id_module FOREIGN KEY (id_module) REFERENCES public.module(id) ON DELETE CASCADE;


--
-- Name: journal_answer fk_journal_answer_student_id_student; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.journal_answer
    ADD CONSTRAINT fk_journal_answer_student_id_student FOREIGN KEY (id_student) REFERENCES public.student(id) ON DELETE CASCADE;


--
-- Name: pre_test_answer fk_pre_test_answer_pre_test_option_id_option; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pre_test_answer
    ADD CONSTRAINT fk_pre_test_answer_pre_test_option_id_option FOREIGN KEY (id_option) REFERENCES public.pre_test_option(id) ON DELETE CASCADE;


--
-- Name: pre_test_answer fk_pre_test_answer_student_id_student; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pre_test_answer
    ADD CONSTRAINT fk_pre_test_answer_student_id_student FOREIGN KEY (id_student) REFERENCES public.student(id) ON DELETE CASCADE;


--
-- Name: pre_test_option fk_pre_test_option_pre_test_question_id_question; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pre_test_option
    ADD CONSTRAINT fk_pre_test_option_pre_test_question_id_question FOREIGN KEY (id_question) REFERENCES public.pre_test_question(id) ON DELETE CASCADE;


--
-- Name: pre_test_question fk_pre_test_question_module_id_module; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pre_test_question
    ADD CONSTRAINT fk_pre_test_question_module_id_module FOREIGN KEY (id_module) REFERENCES public.module(id) ON DELETE CASCADE;


--
-- Name: preliminary_assignment_answer fk_preliminary_assignment_answer_module_id_module; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.preliminary_assignment_answer
    ADD CONSTRAINT fk_preliminary_assignment_answer_module_id_module FOREIGN KEY (id_module) REFERENCES public.module(id) ON DELETE CASCADE;


--
-- Name: preliminary_assignment_answer fk_preliminary_assignment_answer_student_id_student; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.preliminary_assignment_answer
    ADD CONSTRAINT fk_preliminary_assignment_answer_student_id_student FOREIGN KEY (id_student) REFERENCES public.student(id) ON DELETE CASCADE;


--
-- Name: preliminary_assignment_question fk_preliminary_assignment_question_module_id_module; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.preliminary_assignment_question
    ADD CONSTRAINT fk_preliminary_assignment_question_module_id_module FOREIGN KEY (id_module) REFERENCES public.module(id) ON DELETE CASCADE;


--
-- Name: student fk_student_user_id_user; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.student
    ADD CONSTRAINT fk_student_user_id_user FOREIGN KEY (id_user) REFERENCES public."user"(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

